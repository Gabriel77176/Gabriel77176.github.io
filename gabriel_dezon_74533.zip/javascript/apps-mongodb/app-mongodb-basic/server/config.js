export const PORT = 5000;

export const mongoDBUri = "mongodb+srv://munnellyb:Tipp99Baunreagh@cluster0.vhzcxfj.mongodb.net/?retryWrites=true&w=majority"