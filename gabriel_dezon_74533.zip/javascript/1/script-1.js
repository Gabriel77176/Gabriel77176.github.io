// This is a single-line JavaScript comment

console.log("Hello from external JavaScript file.")